<?php

class User
{
    public $user_id, $password, $account_type, $full_name, $email, $contact, $department, $blood_group, $gender, $address, $deactivated, $creation_date, $last_modified;

    public $variable_name = array();

    public function __construct()
    {
        $this->listVName();
        $this->resetVariable();
    }

    public function setValue($user_id, $password, $account_type, $full_name, $email, $contact, $department, $blood_group, $gender, $address)
    {
        $this->user_id = $user_id;
        $this->password = $password;
        $this->account_type = $account_type;
        $this->full_name = $full_name;
        $this->email = $email;
        $this->contact = $contact;
        $this->department = $department;
        $this->blood_group = $blood_group;
        $this->gender = $gender;
        $this->address = $address;
        // $this->deactivated = $deactivated;
        // $this->creation_date = $creation_date;
        // $this->last_modified = $last_modified;
    }

    public function listVName()
    {
        $this->variable_name = array(
            "user_id", "password", "account_type", "full_name", "email",
            "contact", "department", "blood_group", "gender", "address",
            "deactivated", "creation_date", "last_modified"
        );
    }

    public function resetVariable()
    {
        $this->user_id = "";
        $this->password = "";
        $this->account_type = "";
        $this->full_name = "";
        $this->email = "";
        $this->contact = "";
        $this->department = "";
        $this->blood_group = "";
        $this->gender = "";
        $this->address = "";
        $this->deactivated = 0;
        $this->creation_date = "";
        $this->last_modified = "";
    }

    public function createUserTable()
    {
        $query = "CREATE TABLE IF NOT EXISTS tbl_user (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(255),
            password VARCHAR(255) NOT NULL,
            account_type VARCHAR(50) NOT NULL,
            full_name VARCHAR(100),
            email VARCHAR(100),
            contact VARCHAR(15),
            department VARCHAR(100),
            blood_group VARCHAR(5),
            gender VARCHAR(100),
            address VARCHAR(255),
            deactivated INT DEFAULT 0,
            creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        return $query;
    }

    public function insertUser()
    {
        $query = "INSERT INTO tbl_user (user_id, password, account_type, full_name, email, contact, department, blood_group, gender, address, deactivated) 
              VALUES ('{$this->user_id}', '{$this->password}', '{$this->account_type}', '{$this->full_name}', '{$this->email}', '{$this->contact}', '{$this->department}', '{$this->blood_group}', '{$this->gender}', '{$this->address}', {$this->deactivated})";

        return $query;
    }


    public function updateUser()
    {
        $query = "UPDATE tbl_user SET 
                account_type = '{$this->account_type}',
                full_name = '{$this->full_name}',
                email = '{$this->email}',
                contact = '{$this->contact}',
                department = '{$this->department}',
                blood_group = '{$this->blood_group}',
                gender = '{$this->gender}',
                address = '{$this->address}',
                deactivated = {$this->deactivated}
                WHERE " . $this->variable_name[0] . " = '{$this->user_id}'";

        return $query;
    }

    public function deactivateUser($user_id)
    {
        $query = "UPDATE tbl_student SET 
            deactivated = 1
            WHERE " . $this->variable_name[0] . " = '{$user_id}'";

        return $query;
    }
}

?>

<!--  -->
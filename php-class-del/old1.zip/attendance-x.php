<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sias";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
} else {
    echo "Connected\n";
}

mysqli_close($conn);

?>


<?php
class AttendanceX
{
    public $date, $student_id, $attendance;

    public function __construct()
    {
        $this->listVName();
        $this->resetVariable();
    }

    public function setValue($date, $student_id, $attendance)
    {
        $this->date = $date;
        $this->student_id = $student_id;
        $this->attendance = $attendance;
    }

    public function listVName()
    {
        $this->variable_name[] = "date";
        $this->variable_name[] = "student_id";
        $this->variable_name[] = "attendance";
    }

    public function resetVariable()
    {
        $this->date = "";
        $this->student_id = "";
    }

    public function createAttendanceXTable($course_id)
    {
        $query = "CREATE TABLE IF NOT EXISTS tbl_" . $course_id .  " (
            id INT AUTO_INCREMENT PRIMARY KEY,
            date DATE,
            student_id VARCHAR(255),
            attendance INT,
            last_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        return $query;
    }

    public function doAttendance($course_id, $student_id, $attendance)
    {
        $tbl_name = "tbl_" . $course_id;

        $query = "INSERT INTO '{$tbl_name}' (student_id, attendance) 
                  VALUES ('{$student_id}', {$attendance})";

        return $query;
    }


    public function changeAttendance($course_id, $student_id, $attendance)
    {
        $tbl_name = "tbl_" . $course_id;
        // $query = "UPDATE  SET 
        //     attendance = " . $attendance . "
        //     WHERE " . $this->variable_name[1] . " = '{$student_id}'";

        $query = "UPDATE tbl_{$course_id} SET 
            attendance = {$attendance}
            WHERE " . $this->variable_name[1] . " = '{$student_id}'";

        return $query;
    }
}


$obj = new AttendanceX();
if (mysqli_query($conn, $obj->createAttendanceXTable(190122))) {
    echo "New table created successfully";
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);

?>
<!--  -->
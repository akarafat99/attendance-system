<?php
class CourseDetails
{
    public $course_id, $taken_by, $session, $department, $course_code, $course_title, $credit, $completed, $creation_date, $last_modified;

    public $variable_name = array();

    public function __construct()
    {
        $this->listVName();
        $this->resetVariable();
    }

    public function setValue($taken_by, $session, $department, $course_code, $course_title, $credit)
    {
        $this->taken_by = $taken_by;
        $this->session = $session;
        $this->department = $department;
        $this->course_code = $course_code;
        $this->course_title = $course_title;
        $this->credit = $credit;
    }

    public function listVName()
    {
        $this->variable_name[] = "course_id";
        $this->variable_name[] = "taken_by";
        $this->variable_name[] = "session";
        $this->variable_name[] = "department";
        $this->variable_name[] = "course_code";
        $this->variable_name[] = "course_title";
        $this->variable_name[] = "credit";
        $this->variable_name[] = "completed";
        $this->variable_name[] = "creation_date";
        $this->variable_name[] = "last_modified";
    }

    public function resetVariable()
    {
        $this->taken_by = "";
        $this->session = "";
        $this->department = "";
        $this->course_code = "";
        $this->course_title = "";
        $this->credit = 0;
        $this->completed = 0;
        $this->creation_date = "";
        $this->last_modified = "";
    }

    public function createCourseDetailsTable()
    {
        $query = "CREATE TABLE IF NOT EXISTS tbl_course_details (
            course_id INT AUTO_INCREMENT PRIMARY KEY,
            taken_by VARCHAR(255) NOT NULL,
            session VARCHAR(255) NOT NULL,
            department VARCHAR(100),
            course_code VARCHAR(50) NOT NULL,
            course_title VARCHAR(255),
            credit INT,
            completed INT DEFAULT 0,
            creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        return $query;
    }

    public function createCourse()
    {
        $query = "INSERT INTO tbl_course_details (taken_by, session, department, course_code, course_title, credit) 
              VALUES ('{$this->taken_by}', '{$this->session}', '{$this->department}', '{$this->course_code}', '{$this->course_title}', {$this->credit})";

        return $query;
    }


    public function completedCourse($course_id)
    {
        $query = "UPDATE tbl_course_details SET 
            completed = 1
            WHERE " . $this->variable_name[0] . " = '{$course_id}'";

        return $query;
    }
}
?>
<!--  -->
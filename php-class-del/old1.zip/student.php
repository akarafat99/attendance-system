<?php

class Student extends User
{
    public $session, $registration_number;

    public function __construct()
    {
        parent::__construct();
        $this->listVName();
        $this->resetVariable();
    }

    public function setValue($user_id, $password, $account_type, $full_name, $email, $contact, $department, $blood_group, $gender, $address, $session, $registration_number)
    {
        parent::setValue($user_id, $password, $account_type, $full_name, $email, $contact, $department, $blood_group, $gender, $address);
        $this->session = $session;
        $this->registration_number = $registration_number;
    }

    public function listVName()
    {
        parent::listVName();
        $this->variable_name[] = "session";
        $this->variable_name[] = "registration_number";
    }

    public function resetVariable()
    {
        parent::resetVariable();
        $this->session = "";
        $this->registration_number = "";
    }

    public function createStudentTable()
    {
        $query = "CREATE TABLE IF NOT EXISTS tbl_student (
            user_id VARCHAR(255) PRIMARY KEY,
            session VARCHAR(255) NOT NULL,
            registration_number VARCHAR(50) NOT NULL,
            creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";

        return $query;
    }

    public function createStudent()
    {
        $query = "INSERT INTO tbl_student (user_id, session, registration_number) 
                  VALUES ('{$this->user_id}', '{$this->session}', '{$this->registration_number}')";

        return $query;
    }


    public function updateStudent()
    {
        $query = "UPDATE tbl_student SET 
            session = '{$this->session}',
            registration_number = '{$this->registration_number}'
            WHERE " . $this->variable_name[0] . " = '{$this->user_id}'";

        return $query;
    }

    // public function deleteStudent()
    // {
    //     $query = "UPDATE tbl_student SET 
    //         session = '{$this->session}',
    //         registration_number = '{$this->registration_number}'
    //         WHERE " . $this->variable_name[0] . " = '{$this->user_id}'";

    //     return $query;
    // }

}

?>
<!--  -->
<?php
include 'attendance-x.php';

class TableName
{
    public $allTableName = array();

    public $tbl_user = "tbl_user";
    public $tbl_student = "tbl_student";
    public $tbl_course_details = "tbl_course_details";
    public $tbl_attendance_x = "tbl_attendance_x";

    public function __construct()
    {
        $this->addTableNameInOne();
    }

    public function addTableNameInOne()
    {
        $this->allTableName[] = $this->tbl_user;
        $this->allTableName[] = $this->tbl_student;
        $this->allTableName[] = $this->tbl_course_details;
        $this->allTableName[] = $this->tbl_attendance_x;
    }
}

class TableCreate extends TableName
{
    public $query1 = "";
    public $table;
    public function createTable($tbl_name, $course_id)
    {
        if ($tbl_name == $this->tbl_user) {
            $table = new User();
            $query1 = $table->createUserTable();
        } elseif ($tbl_name == $this->tbl_student) {
            $table = new Student();
            $query1 = $table->createStudentTable();
        } elseif ($tbl_name == $this->tbl_course_details) {
            $table = new CourseDetails();
            $query1 = $table->createCourseDetailsTable();
        } elseif ($tbl_name == $this->tbl_attendance_x) {
            $table = new AttendanceX();
            $query1 = $table->createAttendanceXTable(1234);
        }
        echo $query1;
    }
}

$v = new TableCreate();
$v->createTable($v->tbl_attendance_x, 190122);

?>



<!-- 1 -->